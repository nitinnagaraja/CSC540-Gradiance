CREATE DATABASE  IF NOT EXISTS `gradience` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `gradience`;
-- MySQL dump 10.13  Distrib 5.6.17, for Win64 (x86_64)
--
-- Host: localhost    Database: gradience
-- ------------------------------------------------------
-- Server version	5.6.21-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `hw_stud_marks`
--

DROP TABLE IF EXISTS `hw_stud_marks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hw_stud_marks` (
  `hw_stud_marks_hwid` int(11) NOT NULL,
  `hw_stud_marks_uid` varchar(10) NOT NULL,
  `hw_stud_marks_attemptnum` int(11) NOT NULL,
  `hw_stud_marks_marks` int(11) DEFAULT NULL,
  PRIMARY KEY (`hw_stud_marks_hwid`,`hw_stud_marks_uid`,`hw_stud_marks_attemptnum`),
  KEY `hw_stud_marks_uid_idx` (`hw_stud_marks_uid`),
  CONSTRAINT `hw_stud_marks_hwid` FOREIGN KEY (`hw_stud_marks_hwid`) REFERENCES `homework` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `hw_stud_marks_uid` FOREIGN KEY (`hw_stud_marks_uid`) REFERENCES `students` (`uid`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hw_stud_marks`
--

LOCK TABLES `hw_stud_marks` WRITE;
/*!40000 ALTER TABLE `hw_stud_marks` DISABLE KEYS */;
INSERT INTO `hw_stud_marks` VALUES (1,'jmick',1,32),(1,'mjones',1,24),(1,'mjones',2,28),(2,'aneela',1,12),(2,'aneela',2,20),(2,'aneela',3,28),(2,'mjones',1,20),(2,'mjones',2,24),(2,'mjones',3,30);
/*!40000 ALTER TABLE `hw_stud_marks` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-10-23  0:04:20
