CREATE DATABASE  IF NOT EXISTS `gradience2` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `gradience2`;
-- MySQL dump 10.13  Distrib 5.6.17, for Win64 (x86_64)
--
-- Host: localhost    Database: gradience2
-- ------------------------------------------------------
-- Server version	5.6.21-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `questionbank`
--

DROP TABLE IF EXISTS `questionbank`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `questionbank` (
  `questionbank_qid` int(11) NOT NULL,
  `questionbank_text` varchar(200) DEFAULT NULL,
  `questionbank_level` int(11) DEFAULT NULL,
  `questionbank_hint` varchar(100) DEFAULT NULL,
  `questionbank_explanation` varchar(100) DEFAULT NULL,
  `questionbank_type` varchar(45) DEFAULT NULL,
  `questionbank_topic` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`questionbank_qid`),
  KEY `questionbank_topic_idx` (`questionbank_topic`),
  CONSTRAINT `questionbank_topic` FOREIGN KEY (`questionbank_topic`) REFERENCES `chapters` (`chapters_title`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `questionbank`
--

LOCK TABLES `questionbank` WRITE;
/*!40000 ALTER TABLE `questionbank` DISABLE KEYS */;
INSERT INTO `questionbank` VALUES (1,'Question 1 (Q1)',2,'Hint: Hint text Q1','Detailed explanation: detailed explanation Q1','simple','Introduction to database design'),(2,'Question 2 (Q2)',3,'Hint: Hint text Q2','Detailed explanation: detailed explanation Q2','simple','Introduction to database design'),(3,'Question 3 (Q3)',4,'Hint: Hint text Q3','Detailed explanation: detailed explanation Q3','simple','Storing data: Disks and Files'),(4,'Question 4 (Q4)',2,'Hint: Hint text Q4','Detailed explanation: detailed explanation Q4','simple','Storing data: Disks and Files'),(5,'Question 5 (Q5)',3,'Hint: Hint text Q5','Detailed explanation: detailed explanation Q5','simple','Introduction to database design'),(6,'Question 6 (Q6)',5,'Hint: Hint text Q6','Detailed explanation: detailed explanation Q6','simple','Introduction to database design'),(7,'Question 7 (Q7)',2,'Hint: Hint text Q7','Detailed explanation: detailed explanation Q7','simple','Storing data: Disks and Files'),(8,'Question 8 (Q8)',2,'Hint: Hint text Q8','Detailed explanation: detailed explanation Q8','simple','Storing data: Disks and Files'),(9,'Question 9 (Q9)',3,'Hint: Hint text Q9','Detailed explanation: detailed explanation Q9','simple','Tree Structures'),(10,'Question 10 (Q10)',1,'Hint: Hint text Q10','Detailed explanation: detailed explanation Q10','simple','Tree Structures'),(11,'Consider a disk with a sector size = <1>,tracks per surface = <2>, sectors per track = <3>, double-sided platters = <4>, average seek time = <5> . What is the capacity of a track in bytes?',3,'Hint: Hint text Q11','Detailed explanation: detailed explanation Q11','param','Storing data: Disks and Files');
/*!40000 ALTER TABLE `questionbank` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `gradience2`.`questionbank_BEFORE_INSERT` BEFORE INSERT ON `questionbank` FOR EACH ROW
     BEGIN  
    DECLARE dummy,baddata INT;  
    SET baddata = 0;  
    
    IF NEW.questionbank_level>5 THEN  
        SET baddata = 1;  
    END IF; 
    IF NEW.questionbank_level<1 THEN  
        SET baddata = 1;  
    END IF; 
    
    IF baddata = 1 THEN  
        SELECT CONCAT('Cannot insert this because questionbank_level violates the level constraints')  
        INTO dummy FROM information_schema.tables;
    END IF;  
    
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `gradience2`.`questionbank_BEFORE_UPDATE` BEFORE UPDATE ON `questionbank` FOR EACH ROW
         BEGIN  
    DECLARE dummy,baddata INT;  
    SET baddata = 0;  
    
    IF NEW.questionbank_level>5 THEN  
        SET baddata = 1;  
    END IF; 
    IF NEW.questionbank_level<1 THEN  
        SET baddata = 1;  
    END IF; 
    
    IF baddata = 1 THEN  
        SELECT CONCAT('Cannot update this because questionbank_level violates the level constraints')  
        INTO dummy FROM information_schema.tables;
    END IF;  
    
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-10-27 23:50:58
