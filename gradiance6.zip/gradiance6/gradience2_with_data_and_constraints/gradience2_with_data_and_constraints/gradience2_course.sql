CREATE DATABASE  IF NOT EXISTS `gradience2` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `gradience2`;
-- MySQL dump 10.13  Distrib 5.6.17, for Win64 (x86_64)
--
-- Host: localhost    Database: gradience2
-- ------------------------------------------------------
-- Server version	5.6.21-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `course`
--

DROP TABLE IF EXISTS `course`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `course` (
  `course_id` varchar(45) NOT NULL,
  `course_name` varchar(45) DEFAULT NULL,
  `course_maxenroll` int(11) DEFAULT NULL,
  `course_numenrolled` int(11) DEFAULT NULL,
  `course_level` varchar(45) DEFAULT NULL,
  `course_token` varchar(45) DEFAULT NULL,
  `course_startdate` date DEFAULT NULL,
  `course_enddate` date DEFAULT NULL,
  `course_professor` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`course_id`),
  KEY `course_professor_idx` (`course_professor`),
  CONSTRAINT `course_professor` FOREIGN KEY (`course_professor`) REFERENCES `professor` (`professor_uid`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `course`
--

LOCK TABLES `course` WRITE;
/*!40000 ALTER TABLE `course` DISABLE KEYS */;
INSERT INTO `course` VALUES ('CSC440','Database Systems',5,3,'undergrad','CSC440FALL14','2014-08-27','2014-12-12','rchirkova'),('CSC540','Database Systems',5,3,'grad','CSC540FALL14','2014-08-25','2014-12-10','kogan'),('CSC541','Advanced Data Structures',5,3,'grad','CSC541FALL14','2013-08-25','2013-12-06','chealey');
/*!40000 ALTER TABLE `course` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `gradience2`.`course_BEFORE_INSERT` BEFORE INSERT ON `course` FOR EACH ROW
    BEGIN  
    DECLARE dummy,baddata INT;  
    SET baddata = 0;  
    
    IF NEW.course_numenrolled>NEW.course_maxenroll THEN  
        SET baddata = 1;  
    END IF; 
    IF NEW.course_startdate>NEW.course_enddate THEN  
        SET baddata = 2;  
    END IF; 
    
    IF baddata = 1 THEN  
        SELECT CONCAT('Cannot insert this because course_numenrolled exceeds course_maxenroll')  
        INTO dummy FROM information_schema.tables;
    END IF;  
    IF baddata = 2 THEN  
        SELECT CONCAT('Cannot insert this because course start date is greater than course end date')  
        INTO dummy FROM information_schema.tables;
    END IF;  
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `gradience2`.`course_BEFORE_UPDATE` BEFORE UPDATE ON `course` FOR EACH ROW
    BEGIN  
    DECLARE dummy,baddata INT;  
    SET baddata = 0;  
    
    IF NEW.course_numenrolled>NEW.course_maxenroll THEN  
        SET baddata = 1;  
    END IF; 
    IF NEW.course_startdate>NEW.course_enddate THEN  
        SET baddata = 2;  
    END IF; 
    
    IF baddata = 1 THEN  
        SELECT CONCAT('Cannot update this because course_numenrolled exceeds course_maxenroll')  
        INTO dummy FROM information_schema.tables;
    END IF;  
    IF baddata = 2 THEN  
        SELECT CONCAT('Cannot update this because course start date is greater than course end date')  
        INTO dummy FROM information_schema.tables;
    END IF;  
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-10-27 23:50:59
