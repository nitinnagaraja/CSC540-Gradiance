CREATE DATABASE  IF NOT EXISTS `gradience2` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `gradience2`;
-- MySQL dump 10.13  Distrib 5.6.17, for Win64 (x86_64)
--
-- Host: localhost    Database: gradience2
-- ------------------------------------------------------
-- Server version	5.6.21-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `homework_chapters`
--

DROP TABLE IF EXISTS `homework_chapters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `homework_chapters` (
  `homework_chapters_hid` varchar(45) NOT NULL,
  `homework_chapters_title` varchar(45) NOT NULL,
  PRIMARY KEY (`homework_chapters_hid`,`homework_chapters_title`),
  KEY `homework_chapters_title_idx` (`homework_chapters_title`),
  CONSTRAINT `homework_chapters_hid` FOREIGN KEY (`homework_chapters_hid`) REFERENCES `homework` (`homework_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `homework_chapters_title` FOREIGN KEY (`homework_chapters_title`) REFERENCES `chapters` (`chapters_title`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `homework_chapters`
--

LOCK TABLES `homework_chapters` WRITE;
/*!40000 ALTER TABLE `homework_chapters` DISABLE KEYS */;
INSERT INTO `homework_chapters` VALUES ('1','Additional Features of ER Model'),('2','Aggregate Operators'),('3','Data striping'),('1','Database design and ER diagram'),('2','Group by and Having clause'),('1','Introduction to database design'),('1','Key Constraints'),('3','Magnetic disks'),('1','Participation Constraints'),('3','Redundancy'),('3','Redundant Arrays of Independent disks'),('2','SQL: Queries, Constraints, Triggers'),('3','Storing data: Disks and Files'),('3','The Memory Hierarchy'),('2','Union, Intersect and Except');
/*!40000 ALTER TABLE `homework_chapters` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-10-26 22:34:00
