unity IDs:
ggpalank
nchakra2
spati2
nnagara2

------------------------
Front end
------------------------

1) Install Python 2.7.8
	https://www.python.org/downloads/
	
	
2) Install django 1.7.1 from source code
	Django source code is present in main folder. Unzip it and run the following command
	python setup.py install

3) Install MySQL using mysql installer preovide in the main folder

4)  Install Mysqldb python connector (MySQL-python-1.2.4b4.tar.gz) 
	Extract the tar file and run the following command
	python setup.py install

5) 'Gradiance' is the main folder where the project code is present. This is a web application and we need to run 
	the server in localhost to run the application.

6) 	Before deploying the code to server, following changes should be done.

	i) Open the Gradiance folder and you will find one more folder called 'Gradiance'
	ii) Find a python file called 'settings.py'
	iii) Make the following changes in 'settings.py'
		a) 	Find 'DATABASES' section and change the database name, username and password according to your local machine installation
		b)	Cahnge the PROJECT_ROOT variable to the local project location
		c) 	Similarly change the paths in STATICFILES_DIRS ,TEMPLATE_DIRS variables

7) 	Go to main project folder 'Gradiance'

8) 	Execute the following commands to run the server in localhost
	python manage.py syncdb
	python manage.py runserver

9) 	The web application is run in the following address
	127.0.0.1:8000/gradiance/login/
	
	
--------------------------
Database
--------------------------
We have used the following to implement the database:

- MySQL Workbench 6.2 CE
- MySQL server version: 5.0.27-standard MySQL Community Edition - Standard (GPL)

The MySQL tables along with the data can be obtained by importing the sql files attached under gradiance_schema.zip
